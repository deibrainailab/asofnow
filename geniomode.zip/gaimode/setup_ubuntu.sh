#!/usr/bin/env bash
# One-shot setup for a fresh Ubuntu 22.04/24.04 server.
set -euo pipefail

echo "==> system packages"
sudo apt-get update -y
sudo apt-get install -y python3 python3-venv python3-pip xvfb ca-certificates \
     fonts-liberation libnss3 libatk1.0-0 libatk-bridge2.0-0 libcups2 \
     libdrm2 libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 libxrandr2 \
     libgbm1 libasound2t64 libpango-1.0-0 libcairo2 2>/dev/null || \
sudo apt-get install -y libasound2

echo "==> python venv"
python3 -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
pip install --upgrade pip wheel

echo "==> python deps"
pip install -r requirements.txt

echo "==> browser binaries"
# Playwright chromium/firefox (fallback engines)
python -m playwright install --with-deps chromium firefox || python -m playwright install chromium firefox
# Camoufox (hardened Firefox, the default engine - best stealth)
python -m camoufox fetch || echo "camoufox fetch failed; use GAIM_ENGINE=chromium"

echo "==> tuning limits"
# headless browsers open a lot of fds
ulimit -n 65535 || true
if ! grep -q "gaimode" /etc/security/limits.conf 2>/dev/null; then
  echo "* soft nofile 65535   # gaimode" | sudo tee -a /etc/security/limits.conf >/dev/null
  echo "* hard nofile 65535   # gaimode" | sudo tee -a /etc/security/limits.conf >/dev/null
fi

# /dev/shm is tiny on many VPS images -> chromium crashes. Enlarge it.
if [ "$(df -m /dev/shm | awk 'NR==2{print $2}')" -lt 1024 ]; then
  echo "==> remounting /dev/shm to 2G"
  sudo mount -o remount,size=2G /dev/shm || true
fi

echo
echo "Setup done. Activate with:  source .venv/bin/activate"
echo "Smoke test:                 python -m gaimode test 'why is the sky blue'"
