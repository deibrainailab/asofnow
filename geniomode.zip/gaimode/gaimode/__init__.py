"""gaimode - a free, self-hosted Google AI Mode (udm=50) scraper."""
__version__ = "1.0.0"
