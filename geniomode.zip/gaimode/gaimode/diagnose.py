"""`python -m gaimode diagnose` - figure out *why* you are being blocked.

Runs a staged probe and prints a verdict with a concrete next step:
  stage 1  what is our egress IP / country (no browser)
  stage 2  can we load the Google homepage at all
  stage 3  does a plain (non-AI) search work
  stage 4  does udm=50 AI Mode work
Artifacts (screenshot + HTML) for every failing stage land in data/debug/.
"""
from __future__ import annotations

import asyncio
import json
import time
from typing import Any, Optional

from .browser import BrowserManager, ProxyPool
from .config import Settings
from .extract import (BlockKind, CONTAINER_SELECTORS, DETECT_JS, EXTRACT_JS,
                      classify)

LINE = "-" * 72

VERDICT = {
    BlockKind.SORRY: (
        "IP BANNED. Google served the /sorry/ CAPTCHA wall.",
        ["This IP is burned for AI Mode - it is not a code problem.",
         "Put residential proxies in proxies.txt (datacenter IPs get banned in minutes).",
         "Wait 30-60 min for a soft ban on this IP to decay, or change IP.",
         "Then lower the rate: GAIM_WORKERS=2 GAIM_MIN_DELAY_S=4 GAIM_MAX_DELAY_S=9"],
    ),
    BlockKind.RECAPTCHA: (
        "reCAPTCHA challenge rendered inline.",
        ["Same as a ban: rotate IP, slow down.",
         "Try GAIM_ENGINE=camoufox - plain Chromium is fingerprinted far more easily."],
    ),
    BlockKind.CONSENT: (
        "COOKIE CONSENT WALL - this is NOT a ban and is fully fixable.",
        ["The SOCS/CONSENT cookies did not take for your region.",
         "Try a matching region: GAIM_GL=in GAIM_HL=en (or gl=us with a US proxy).",
         "Run with --no-headless once and accept the dialog manually to see it."],
    ),
    BlockKind.HTTP: (
        "Google returned HTTP 429/503 - rate limited.",
        ["Reduce GAIM_WORKERS and raise GAIM_MIN_DELAY_S / GAIM_MAX_DELAY_S.",
         "Add more proxies so each IP sees fewer requests per minute."],
    ),
    BlockKind.JS_OFF: (
        "Google thinks JavaScript is disabled.",
        ["GAIM_BLOCK_ASSETS is probably over-blocking. Set GAIM_BLOCK_ASSETS=0 and retry."],
    ),
}


async def _probe(page, s: Settings, url: str, tag: str) -> dict[str, Any]:
    out: dict[str, Any] = {"tag": tag, "url": url}
    try:
        resp = await page.goto(url, wait_until="domcontentloaded",
                               timeout=s.nav_timeout_ms)
        out["status"] = resp.status if resp else 0
    except Exception as exc:
        out["status"] = -1
        out["error"] = f"{type(exc).__name__}: {exc}"
        return out

    await page.wait_for_timeout(1500)
    try:
        probe = await page.evaluate(DETECT_JS)
    except Exception as exc:
        probe = {}
        out["error"] = str(exc)
    out["final_url"] = probe.get("url", page.url)
    out["title"] = probe.get("title", "")
    out["text_len"] = probe.get("textLen", 0)
    out["has_search_box"] = probe.get("hasSearchBox", False)
    out["has_ai_container"] = probe.get("aiContainer", False)
    out["kind"] = classify(probe, out["status"])
    out["snippet"] = (probe.get("text") or "")[:300].replace("\n", " ")

    if out["kind"] or tag == "ai_mode":
        s.ensure_dirs()
        stamp = int(time.time())
        png = s.debug_dir / f"diag_{tag}_{stamp}.png"
        htm = s.debug_dir / f"diag_{tag}_{stamp}.html"
        try:
            await page.screenshot(path=str(png), full_page=False)
            htm.write_text((await page.content())[:3_000_000], encoding="utf-8")
            out["screenshot"] = str(png)
            out["html"] = str(htm)
        except Exception:
            pass
    return out


async def run_diagnose(s: Settings, query: str, use_proxy: bool = True) -> int:
    print(LINE)
    print("gaimode diagnose")
    print(LINE)

    # ---- stage 1: egress IP ------------------------------------------------
    pool = ProxyPool(s.proxy_file)
    proxy = await pool.next() if use_proxy else None
    print(f"engine        : {s.engine}")
    print(f"headless      : {s.headless}")
    print(f"block_assets  : {s.block_assets}")
    print(f"hl/gl         : {s.hl}/{s.gl}")
    print(f"proxies loaded: {len(pool.proxies)}")
    print(f"using proxy   : {proxy['server'] if proxy else 'NONE (server IP)'}")
    if not pool.proxies:
        print("  ^ WARNING: no proxies. A bare server IP is the #1 cause of this error.")
    print(LINE)

    mgr = BrowserManager(s)
    await mgr.start(proxy)
    results: list[dict[str, Any]] = []
    try:
        ctx = await mgr.new_context()
        page = await ctx.new_page()

        # egress IP as Google sees it
        try:
            await page.goto("https://api.ipify.org?format=json",
                            wait_until="domcontentloaded", timeout=20000)
            ip = json.loads(await page.inner_text("body")).get("ip")
            print(f"stage 0  egress IP        : {ip}")
        except Exception as exc:
            print(f"stage 0  egress IP        : could not determine ({exc})")

        stages = [
            ("homepage", f"https://{s.domain}/?hl={s.hl}&gl={s.gl}"),
            ("plain_search",
             f"https://{s.domain}/search?q={query.replace(' ', '+')}&hl={s.hl}&gl={s.gl}"),
            ("ai_mode",
             f"https://{s.domain}/search?q={query.replace(' ', '+')}"
             f"&udm=50&aep=11&hl={s.hl}&gl={s.gl}"),
        ]

        for tag, url in stages:
            r = await _probe(page, s, url, tag)
            results.append(r)
            kind = r.get("kind") or "ok"
            print(f"stage {len(results)}  {tag:<16}: HTTP {r.get('status')} "
                  f"| {kind} | text={r.get('text_len')} chars")
            if r.get("title"):
                print(f"         title            : {r['title'][:80]}")
            if r.get("final_url", "") != url:
                print(f"         redirected to    : {r.get('final_url', '')[:100]}")
            if r.get("error"):
                print(f"         error            : {r['error'][:140]}")
            if r.get("snippet") and r.get("kind"):
                print(f"         page says        : {r['snippet'][:140]}")
            if r.get("screenshot"):
                print(f"         screenshot       : {r['screenshot']}")
                print(f"         html             : {r['html']}")

            # if AI mode loaded, try a real extraction
            if tag == "ai_mode" and not r.get("kind"):
                for _ in range(40):
                    data = await page.evaluate(EXTRACT_JS, CONTAINER_SELECTORS)
                    if len(data.get("text") or "") > s.min_answer_chars:
                        break
                    await page.wait_for_timeout(500)
                data = await page.evaluate(EXTRACT_JS, CONTAINER_SELECTORS)
                txt = data.get("text") or ""
                print(f"         extracted        : {len(txt)} chars via "
                      f"{data.get('selector')}")
                if txt:
                    print(f"         preview          : {txt[:200]}...")
                r["extracted"] = len(txt)
                r["selector"] = data.get("selector")
    finally:
        await mgr.close()

    # ---- verdict -----------------------------------------------------------
    print(LINE)
    print("VERDICT")
    print(LINE)

    blocked = [r for r in results if r.get("kind")]
    ai = next((r for r in results if r["tag"] == "ai_mode"), {})

    if not blocked and ai.get("extracted", 0) > s.min_answer_chars:
        print("Everything works. AI Mode extracted cleanly from this IP.")
        print("If `run` still reports blocks, you are going too fast:")
        print("  GAIM_WORKERS=3 GAIM_MIN_DELAY_S=3 GAIM_MAX_DELAY_S=7")
        return 0

    if not blocked and ai and not ai.get("extracted"):
        print("Not blocked - but no AI answer was extracted.")
        print("Either Google did not serve AI Mode for this query/region, or the")
        print("layout changed. Check the saved screenshot/HTML above.")
        print("  - try GAIM_GL=us (AI Mode coverage is widest in the US)")
        print("  - try a longer, question-shaped query")
        print("  - if the HTML has an answer, add its container to CONTAINER_SELECTORS")
        print("    at the top of gaimode/extract.py")
        return 2

    worst = blocked[-1]["kind"]
    headline, steps = VERDICT.get(worst, (f"Blocked: {worst}", ["Inspect the artifacts above."]))
    print(headline)
    for i, step in enumerate(steps, 1):
        print(f"  {i}. {step}")

    first_bad = blocked[0]["tag"]
    print()
    if first_bad == "homepage":
        print("Note: even the Google HOMEPAGE is blocked -> this is purely an IP")
        print("reputation problem. No amount of scraper tuning will help.")
    elif first_bad == "plain_search":
        print("Note: plain search is blocked too -> IP reputation, not AI Mode specific.")
    else:
        print("Note: homepage + plain search work, only udm=50 is blocked -> Google is")
        print("rate-limiting AI Mode specifically. Slow down and add proxies;")
        print("AI Mode has a much tighter budget per IP than normal search.")
    return 1


def cmd_diagnose(args, s: Settings) -> int:
    if args.engine:
        s.engine = args.engine
    if args.no_headless:
        s.headless = False
    if args.no_proxy:
        pass
    s.save_debug_html = True
    return asyncio.run(run_diagnose(s, args.query, use_proxy=not args.no_proxy))
