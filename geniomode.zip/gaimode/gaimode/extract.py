"""DOM extraction for Google AI Mode (udm=50).

Google ships obfuscated, frequently-rotated class names, so we never rely on a
single selector. Strategy:

  1. Try a list of known AI-Mode container selectors (cheap, exact).
  2. Fall back to a scoring heuristic: inside <main>/#main, pick the block with
     the most prose text that is not the header/footer/related-searches chrome.

The same JS also reports a text length so the caller can poll until the
streamed answer stops growing.
"""
from __future__ import annotations

from urllib.parse import urlsplit as _urlsplit

# Ordered best -> worst. Add new ones at the top when Google changes layout.
CONTAINER_SELECTORS = [
    'div[data-subtree="aimc"]',
    'div[data-am-outer-container]',
    '#m-x-content',
    'div[data-rl][data-mcpr]',
    'div[jsname="rZH0rc"]',
    'div[role="main"] div[data-async-context]',
]

# JS returns: {text, html, sources:[{url,title}], selector, done_hint}
EXTRACT_JS = r"""
(knownSelectors) => {
  const BAD_HOSTS = ['google.com', 'google.co', 'gstatic.com', 'youtube.com/redirect',
                     'policies.google', 'support.google', 'accounts.google'];
  const NOISE = [
    'people also ask', 'related searches', 'sign in', 'accessibility links',
    'skip to main content', 'feedback', 'ai responses may include mistakes'
  ];

  const visible = (el) => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 80 || r.height < 40) return false;
    const s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  };

  const cleanText = (el) => {
    const clone = el.cloneNode(true);
    clone.querySelectorAll('script,style,noscript,svg,button,textarea,input,form')
         .forEach(n => n.remove());
    return (clone.innerText || '').replace(/\u00a0/g, ' ')
                                 .replace(/\n{3,}/g, '\n\n')
                                 .trim();
  };

  // ---- 1. known selectors -------------------------------------------------
  let best = null, bestSel = null;
  for (const sel of knownSelectors) {
    const nodes = document.querySelectorAll(sel);
    for (const n of nodes) {
      if (!visible(n)) continue;
      const t = cleanText(n);
      if (t.length > 100) {
        if (!best || t.length > cleanText(best).length) { best = n; bestSel = sel; }
      }
    }
    if (best) break;
  }

  // ---- 2. heuristic fallback ---------------------------------------------
  if (!best) {
    const root = document.querySelector('#main, [role="main"], #rcnt') || document.body;
    let bestScore = 0;
    const walk = root.querySelectorAll('div, article, section');
    for (const n of walk) {
      if (!visible(n)) continue;
      // skip containers that wrap most of the page
      if (n.contains(document.querySelector('#searchform'))) continue;
      const t = cleanText(n);
      if (t.length < 200 || t.length > 60000) continue;
      const lower = t.slice(0, 200).toLowerCase();
      if (NOISE.some(x => lower.includes(x))) continue;
      // prefer prose-dense blocks with few direct children
      const paras = n.querySelectorAll('p, li, h2, h3').length;
      const links = n.querySelectorAll('a').length;
      const score = t.length + paras * 60 - links * 25 - n.children.length * 5;
      if (score > bestScore) { bestScore = score; best = n; bestSel = 'heuristic'; }
    }
  }

  if (!best) return { text: '', html: '', sources: [], selector: null, done_hint: false };

  // ---- sources ------------------------------------------------------------
  const seen = new Set();
  const sources = [];
  for (const a of best.querySelectorAll('a[href^="http"]')) {
    let href = a.getAttribute('href') || '';
    try {
      const u = new URL(href, location.href);
      if (u.searchParams.get('url')) href = u.searchParams.get('url');
    } catch (e) { continue; }
    if (BAD_HOSTS.some(h => href.includes(h))) continue;
    if (seen.has(href)) continue;
    seen.add(href);
    let title = (a.innerText || a.getAttribute('aria-label') || '').trim();
    if (title.length > 300) title = title.slice(0, 300);
    sources.push({ url: href, title: title });
    if (sources.length >= 60) break;
  }

  // Streaming finished hints: the follow-up composer / feedback bar appears.
  const doneHint = !!document.querySelector(
    'div[data-subtree="aimc"] ~ div textarea, textarea[aria-label*="follow"], ' +
    '[aria-label*="Follow up"], [data-ved][jsname="tCOgAe"]'
  );

  return {
    text: cleanText(best),
    html: best.innerHTML.length > 400000 ? '' : best.innerHTML,
    sources: sources,
    selector: bestSel,
    done_hint: doneHint
  };
}
"""

# --------------------------------------------------------------------------- #
# Block / interstitial detection
#
# NOTE: never substring-match raw HTML for tokens like "recaptcha" -- Google's
# normal SERP bundles contain that string inside inline JS and it produces
# constant false positives. We inspect the rendered DOM instead.
# --------------------------------------------------------------------------- #

DETECT_JS = r"""
() => {
  const t = (document.body ? document.body.innerText : '') || '';
  return {
    url: location.href,
    title: document.title || '',
    text: t.slice(0, 2000),
    textLen: t.length,
    // real, *visible* challenge widgets - not strings in a script bundle
    recaptcha: !!document.querySelector(
      'iframe[src*="/recaptcha/"], div.g-recaptcha, #recaptcha, #captcha-form, ' +
      'form#captcha-form, iframe[title*="recaptcha" i]'),
    consentBtn: !!document.querySelector(
      'button#L2AGLb, button#W0wltc, form[action*="consent"] button, ' +
      'div[role="dialog"] form[action*="consent"]'),
    hasSearchBox: !!document.querySelector('textarea[name="q"], input[name="q"]'),
    aiContainer: !!document.querySelector('div[data-subtree="aimc"], #m-x-content'),
  };
}
"""

# Phrases that only ever appear on a genuine interstitial, checked against the
# rendered *text*, not the source.
_SORRY_TEXT = (
    "unusual traffic from your computer network",
    "our systems have detected unusual traffic",
    "systems have detected unusual traffic",
    "to continue, please type the characters",
    "why did this happen",
    "i'm not a robot",
)

_CONSENT_TEXT = (
    "before you continue to google",
    "before you continue",
    "we use cookies and data to",
    "accept all",
    "reject all",
)


class BlockKind:
    SORRY = "sorry_redirect"          # /sorry/ CAPTCHA wall -> IP is burned
    RECAPTCHA = "recaptcha_widget"    # challenge rendered inline
    CONSENT = "consent_wall"          # EU/IN cookie wall -> NOT a ban, fixable
    HTTP = "http_status"              # 429 / 503
    JS_OFF = "js_required"            # Google thinks JS is disabled
    NONE = ""


def classify(probe: dict, status: int = 200) -> str:
    """Return a BlockKind from a DETECT_JS probe. Empty string = not blocked."""
    url = (probe.get("url") or "").lower()
    text = (probe.get("text") or "").lower()
    title = (probe.get("title") or "").lower()

    if "/sorry/" in url:
        return BlockKind.SORRY
    if any(p in text for p in _SORRY_TEXT) or "unusual traffic" in title:
        return BlockKind.SORRY
    if probe.get("recaptcha"):
        return BlockKind.RECAPTCHA
    if status in (429, 503):
        return BlockKind.HTTP

    # Consent: only when it's actually blocking the page (no SERP behind it).
    # Match host/path precisely - a loose `"/consent" in url` also fires on
    # ordinary URLs (query text, continue= params) and wedges the worker.
    try:
        parsed = _urlsplit(url)
        host, path = parsed.hostname or "", parsed.path or ""
    except Exception:
        host, path = "", ""
    on_consent_host = (
        host.startswith("consent.")
        or host.endswith(".consent.google.com")
        or path == "/consent"
        or path.startswith("/consent/")
    )
    consent_textish = any(p in text for p in _CONSENT_TEXT) or "before you continue" in title
    if on_consent_host or (probe.get("consentBtn") and consent_textish
                           and not probe.get("aiContainer")):
        return BlockKind.CONSENT

    if "enablejs" in url or "javascript is disabled" in text:
        return BlockKind.JS_OFF

    return BlockKind.NONE


# Kept for backwards compatibility with older callers.
def looks_blocked(url: str, html: str) -> bool:
    u = (url or "").lower()
    if "/sorry/" in u:
        return True
    h = (html or "").lower()
    return any(p in h for p in _SORRY_TEXT)
