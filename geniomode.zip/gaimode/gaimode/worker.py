"""Scrape logic + the async worker pool."""
from __future__ import annotations

import asyncio
import logging
import random
import time
import urllib.parse
from dataclasses import dataclass
from typing import Optional

from playwright.async_api import BrowserContext, Error as PWError, Page, TimeoutError as PWTimeout

from .browser import BrowserManager, ProxyPool
from .config import Settings
from .db import JobStore
from .extract import CONTAINER_SELECTORS, EXTRACT_JS, looks_blocked

log = logging.getLogger("gaimode")


class Blocked(Exception):
    """Google served a CAPTCHA / sorry page."""


class NoAnswer(Exception):
    """Page loaded but no AI answer could be extracted."""


@dataclass
class ScrapeResult:
    query: str
    answer: str
    sources: list[dict]
    selector: str
    took_ms: int


def build_url(query: str, s: Settings) -> str:
    params = {
        "q": query,
        "udm": "50",
        "aep": "11",
        "hl": s.hl,
        "gl": s.gl,
    }
    return f"https://{s.domain}/search?" + urllib.parse.urlencode(
        params, quote_via=urllib.parse.quote_plus)


async def _dismiss_consent(page: Page) -> None:
    for sel in ('button#L2AGLb', 'button#W0wltc',
                'form[action*="consent"] button',
                'button:has-text("Accept all")',
                'button:has-text("I agree")'):
        try:
            loc = page.locator(sel).first
            if await loc.count() and await loc.is_visible(timeout=800):
                await loc.click(timeout=2000)
                await page.wait_for_timeout(600)
                return
        except Exception:
            continue


async def scrape_one(page: Page, query: str, s: Settings) -> ScrapeResult:
    """Load AI Mode for `query` and wait until the streamed answer settles."""
    t0 = time.monotonic()
    url = build_url(query, s)

    try:
        resp = await page.goto(url, wait_until="domcontentloaded",
                               timeout=s.nav_timeout_ms)
    except PWTimeout as exc:
        raise NoAnswer(f"navigation timeout: {exc}") from exc

    status = resp.status if resp else 0
    if status in (429, 503):
        raise Blocked(f"http {status}")

    if "consent" in page.url or "/sorry/" in page.url:
        await _dismiss_consent(page)
        if "/sorry/" in page.url:
            raise Blocked("sorry page")

    # Cheap early block check before we start polling.
    try:
        head = await page.content()
    except PWError:
        head = ""
    if looks_blocked(page.url, head):
        raise Blocked("captcha/unusual traffic")

    # ---- poll until the streaming answer stops growing --------------------
    deadline = time.monotonic() + s.answer_timeout_ms / 1000
    last_len, stable_since = -1, None
    data: dict = {}

    while time.monotonic() < deadline:
        try:
            data = await page.evaluate(EXTRACT_JS, CONTAINER_SELECTORS)
        except PWError:
            data = {}
        text = (data or {}).get("text") or ""
        cur = len(text)

        if cur >= s.min_answer_chars and cur == last_len:
            if stable_since is None:
                stable_since = time.monotonic()
            elif (time.monotonic() - stable_since) * 1000 >= s.settle_ms:
                break
        else:
            stable_since = None
        last_len = cur

        await page.wait_for_timeout(s.poll_ms)

    text = (data or {}).get("text") or ""
    if len(text) < s.min_answer_chars:
        try:
            html = await page.content()
        except PWError:
            html = ""
        if looks_blocked(page.url, html):
            raise Blocked("captcha after load")
        if s.save_debug_html:
            s.ensure_dirs()
            fn = s.debug_dir / f"noanswer_{abs(hash(query)) % 10**10}.html"
            fn.write_text(html[:2_000_000], encoding="utf-8")
        raise NoAnswer(f"answer too short ({len(text)} chars)")

    return ScrapeResult(
        query=query,
        answer=text,
        sources=(data.get("sources") or [])[:60],
        selector=data.get("selector") or "?",
        took_ms=int((time.monotonic() - t0) * 1000),
    )


# --------------------------------------------------------------------------- #

class Stats:
    def __init__(self) -> None:
        self.done = 0
        self.failed = 0
        self.blocked = 0
        self.start = time.monotonic()

    def line(self, pending: int) -> str:
        el = max(time.monotonic() - self.start, 1e-6)
        rate = self.done / el
        eta = pending / rate if rate > 0 else float("inf")
        return (f"done={self.done} failed={self.failed} blocked={self.blocked} "
                f"pending={pending} | {rate*60:.1f} q/min | "
                f"eta={eta/3600:.1f}h")


class Scraper:
    def __init__(self, store: JobStore, s: Settings):
        self.store = store
        self.s = s
        self.proxies = ProxyPool(s.proxy_file)
        self.stats = Stats()
        self._stop = asyncio.Event()
        self._cooldown_until = 0.0

    def stop(self) -> None:
        self._stop.set()

    async def _respect_cooldown(self) -> None:
        loop = asyncio.get_event_loop()
        while loop.time() < self._cooldown_until and not self._stop.is_set():
            await asyncio.sleep(min(2.0, self._cooldown_until - loop.time()))

    def _trigger_cooldown(self) -> None:
        loop = asyncio.get_event_loop()
        self._cooldown_until = max(self._cooldown_until,
                                   loop.time() + self.s.block_cooldown_s)

    # ------------------------------------------------------------------ #
    async def _worker(self, wid: int) -> None:
        mgr: Optional[BrowserManager] = None
        ctx: Optional[BrowserContext] = None
        page: Optional[Page] = None
        proxy = None
        ctx_jobs = 0
        browser_jobs = 0

        async def teardown() -> None:
            nonlocal ctx, page, mgr
            for closer in (page, ctx):
                try:
                    if closer:
                        await closer.close()
                except Exception:
                    pass
            page, ctx = None, None
            if mgr:
                await mgr.close()
                mgr = None

        try:
            while not self._stop.is_set():
                await self._respect_cooldown()

                rows = await asyncio.to_thread(self.store.claim, 1)
                if not rows:
                    stats = await asyncio.to_thread(self.store.stats)
                    if stats.get("pending", 0) == 0 and stats.get("running", 0) == 0:
                        return  # queue drained
                    await asyncio.sleep(2.0)
                    continue

                job = rows[0]
                job_id, query = job["id"], job["query"]

                # (re)build browser / context as needed
                if mgr is None or browser_jobs >= self.s.browser_max_jobs:
                    await teardown()
                    proxy = await self.proxies.next()
                    mgr = BrowserManager(self.s)
                    try:
                        await mgr.start(proxy)
                    except Exception as exc:
                        log.error("w%d browser start failed: %s", wid, exc)
                        await asyncio.to_thread(self.store.release, job_id, str(exc))
                        await teardown()
                        await asyncio.sleep(5)
                        continue
                    browser_jobs = 0
                    ctx_jobs = self.s.context_max_jobs  # force fresh context

                if ctx is None or ctx_jobs >= self.s.context_max_jobs:
                    for closer in (page, ctx):
                        try:
                            if closer:
                                await closer.close()
                        except Exception:
                            pass
                    ctx = await mgr.new_context()
                    page = await ctx.new_page()
                    ctx_jobs = 0

                # -------- scrape --------
                try:
                    res = await scrape_one(page, query, self.s)
                except Blocked as exc:
                    self.stats.blocked += 1
                    log.warning("w%d BLOCKED (%s) -> rotating identity", wid, exc)
                    await self.proxies.ban(proxy, 600)
                    await asyncio.to_thread(self.store.release, job_id, f"blocked: {exc}")
                    self._trigger_cooldown()
                    await teardown()
                    ctx_jobs = browser_jobs = 0
                    continue
                except (NoAnswer, PWTimeout, PWError) as exc:
                    dead = await asyncio.to_thread(
                        self.store.retry, job_id, str(exc), self.s.max_attempts)
                    if dead:
                        self.stats.failed += 1
                    log.info("w%d retry/fail %r: %s", wid, query[:60], str(exc)[:120])
                    ctx_jobs = self.s.context_max_jobs  # fresh context next round
                    await asyncio.sleep(random.uniform(1, 3))
                    continue
                except Exception as exc:  # noqa: BLE001 - never kill the worker
                    dead = await asyncio.to_thread(
                        self.store.retry, job_id, repr(exc), self.s.max_attempts)
                    if dead:
                        self.stats.failed += 1
                    log.exception("w%d unexpected error", wid)
                    await teardown()
                    ctx_jobs = browser_jobs = 0
                    continue

                await asyncio.to_thread(self.store.complete, job_id, res.query,
                                        res.answer, res.sources, res.took_ms)
                self.stats.done += 1
                ctx_jobs += 1
                browser_jobs += 1

                await asyncio.sleep(random.uniform(self.s.min_delay_s,
                                                   self.s.max_delay_s))
        finally:
            await teardown()

    # ------------------------------------------------------------------ #
    async def _reporter(self) -> None:
        while not self._stop.is_set():
            await asyncio.sleep(20)
            st = await asyncio.to_thread(self.store.stats)
            log.info("[progress] %s", self.stats.line(st.get("pending", 0)))

    async def run(self) -> None:
        tasks = [asyncio.create_task(self._worker(i)) for i in range(self.s.workers)]
        rep = asyncio.create_task(self._reporter())
        try:
            await asyncio.gather(*tasks)
        finally:
            rep.cancel()
            st = await asyncio.to_thread(self.store.stats)
            log.info("[final] %s", self.stats.line(st.get("pending", 0)))
