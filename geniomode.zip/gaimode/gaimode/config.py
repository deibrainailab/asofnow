"""Central configuration. Everything is overridable via environment variables."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


def _env(key: str, default: str) -> str:
    return os.environ.get(key, default)


def _env_int(key: str, default: int) -> int:
    try:
        return int(os.environ.get(key, default))
    except (TypeError, ValueError):
        return default


def _env_float(key: str, default: float) -> float:
    try:
        return float(os.environ.get(key, default))
    except (TypeError, ValueError):
        return default


def _env_bool(key: str, default: bool) -> bool:
    raw = os.environ.get(key)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}


ROOT = Path(os.environ.get("GAIM_ROOT", Path(__file__).resolve().parent.parent))


@dataclass
class Settings:
    # ---------- storage ----------
    db_path: Path = field(default_factory=lambda: ROOT / "data" / "jobs.db")
    out_dir: Path = field(default_factory=lambda: ROOT / "data" / "out")
    log_dir: Path = field(default_factory=lambda: ROOT / "data" / "logs")
    profile_dir: Path = field(default_factory=lambda: ROOT / "data" / "profiles")
    debug_dir: Path = field(default_factory=lambda: ROOT / "data" / "debug")

    # ---------- concurrency ----------
    # Number of concurrent browser contexts (tabs) inside ONE browser process.
    workers: int = _env_int("GAIM_WORKERS", 4)
    # Recycle a context after this many successful queries (fresh fingerprint/cookies).
    context_max_jobs: int = _env_int("GAIM_CONTEXT_MAX_JOBS", 25)
    # Restart the whole browser process after this many jobs (kills memory leaks).
    browser_max_jobs: int = _env_int("GAIM_BROWSER_MAX_JOBS", 800)

    # ---------- timing ----------
    nav_timeout_ms: int = _env_int("GAIM_NAV_TIMEOUT_MS", 45_000)
    answer_timeout_ms: int = _env_int("GAIM_ANSWER_TIMEOUT_MS", 60_000)
    # Answer is considered finished when innerText stops growing for this long.
    settle_ms: int = _env_int("GAIM_SETTLE_MS", 1_400)
    poll_ms: int = _env_int("GAIM_POLL_MS", 350)
    min_delay_s: float = _env_float("GAIM_MIN_DELAY_S", 1.0)
    max_delay_s: float = _env_float("GAIM_MAX_DELAY_S", 3.5)
    # Global cooldown applied to every worker when Google shows a block page.
    block_cooldown_s: float = _env_float("GAIM_BLOCK_COOLDOWN_S", 90.0)

    # ---------- retries ----------
    max_attempts: int = _env_int("GAIM_MAX_ATTEMPTS", 4)
    min_answer_chars: int = _env_int("GAIM_MIN_ANSWER_CHARS", 120)

    # ---------- browser ----------
    engine: str = _env("GAIM_ENGINE", "camoufox")  # camoufox | chromium | firefox
    headless: bool = _env_bool("GAIM_HEADLESS", True)
    block_assets: bool = _env_bool("GAIM_BLOCK_ASSETS", True)
    save_debug_html: bool = _env_bool("GAIM_SAVE_DEBUG_HTML", False)

    # ---------- google ----------
    hl: str = _env("GAIM_HL", "en")
    gl: str = _env("GAIM_GL", "us")
    domain: str = _env("GAIM_DOMAIN", "www.google.com")

    # ---------- proxies ----------
    # One proxy per line in proxies.txt:  http://user:pass@host:port
    proxy_file: Path = field(default_factory=lambda: ROOT / "proxies.txt")

    def ensure_dirs(self) -> None:
        for d in (self.db_path.parent, self.out_dir, self.log_dir,
                  self.profile_dir, self.debug_dir):
            d.mkdir(parents=True, exist_ok=True)


SETTINGS = Settings()
