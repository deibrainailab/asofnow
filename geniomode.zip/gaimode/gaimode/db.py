"""SQLite-backed job queue.

Chosen over Redis/Celery on purpose: zero services to run, crash-safe, and fast
enough for millions of rows when used in WAL mode with batched claims.

Statuses: pending -> running -> done | failed | blocked(requeued)
"""
from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from pathlib import Path
from typing import Iterable, Iterator, Sequence

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA temp_store=MEMORY;
PRAGMA mmap_size=268435456;

CREATE TABLE IF NOT EXISTS jobs (
    id        INTEGER PRIMARY KEY,
    query     TEXT    NOT NULL UNIQUE,
    status    TEXT    NOT NULL DEFAULT 'pending',
    attempts  INTEGER NOT NULL DEFAULT 0,
    lease_at  REAL    NOT NULL DEFAULT 0,
    error     TEXT,
    updated   REAL    NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_jobs_status  ON jobs(status, id);
CREATE INDEX IF NOT EXISTS idx_jobs_lease   ON jobs(status, lease_at);

CREATE TABLE IF NOT EXISTS results (
    job_id     INTEGER PRIMARY KEY REFERENCES jobs(id),
    query      TEXT NOT NULL,
    answer     TEXT NOT NULL,
    sources    TEXT NOT NULL DEFAULT '[]',
    chars      INTEGER NOT NULL DEFAULT 0,
    took_ms    INTEGER NOT NULL DEFAULT 0,
    scraped_at REAL NOT NULL
);
"""


class JobStore:
    """Thread-safe-ish wrapper: one connection per thread."""

    def __init__(self, path: Path | str):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self._write_lock = threading.Lock()
        with self._conn() as c:
            c.executescript(SCHEMA)

    # ------------------------------------------------------------------ #
    def _conn(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self.path, timeout=60, isolation_level=None,
                                   check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute("PRAGMA synchronous=NORMAL;")
            conn.execute("PRAGMA busy_timeout=60000;")
            self._local.conn = conn
        return conn

    # ------------------------------------------------------------------ #
    def add_queries(self, queries: Iterable[str], batch: int = 20_000) -> int:
        """Bulk-load queries. Duplicates are ignored. Safe to re-run."""
        conn = self._conn()
        added = 0
        buf: list[tuple[str, float]] = []
        now = time.time()

        def flush() -> int:
            if not buf:
                return 0
            with self._write_lock:
                conn.execute("BEGIN")
                cur = conn.executemany(
                    "INSERT OR IGNORE INTO jobs(query, updated) VALUES (?, ?)", buf)
                conn.execute("COMMIT")
            n = cur.rowcount if cur.rowcount and cur.rowcount > 0 else 0
            buf.clear()
            return n

        for q in queries:
            q = (q or "").strip()
            if not q:
                continue
            buf.append((q, now))
            if len(buf) >= batch:
                added += flush()
        added += flush()
        return added

    # ------------------------------------------------------------------ #
    def claim(self, n: int = 1, lease_s: float = 600.0) -> list[sqlite3.Row]:
        """Atomically grab up to `n` pending jobs (also reclaims stale leases)."""
        conn = self._conn()
        now = time.time()
        with self._write_lock:
            conn.execute("BEGIN IMMEDIATE")
            rows = conn.execute(
                """
                SELECT id, query, attempts FROM jobs
                 WHERE status = 'pending'
                    OR (status = 'running' AND lease_at < ?)
                 ORDER BY id LIMIT ?
                """,
                (now, n),
            ).fetchall()
            if rows:
                ids = [r["id"] for r in rows]
                conn.executemany(
                    "UPDATE jobs SET status='running', lease_at=?, updated=? WHERE id=?",
                    [(now + lease_s, now, i) for i in ids],
                )
            conn.execute("COMMIT")
        return rows

    # ------------------------------------------------------------------ #
    def complete(self, job_id: int, query: str, answer: str,
                 sources: Sequence[dict], took_ms: int) -> None:
        conn = self._conn()
        now = time.time()
        with self._write_lock:
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(
                """INSERT OR REPLACE INTO results
                   (job_id, query, answer, sources, chars, took_ms, scraped_at)
                   VALUES (?,?,?,?,?,?,?)""",
                (job_id, query, answer, json.dumps(sources, ensure_ascii=False),
                 len(answer), took_ms, now),
            )
            conn.execute(
                "UPDATE jobs SET status='done', error=NULL, updated=? WHERE id=?",
                (now, job_id))
            conn.execute("COMMIT")

    def retry(self, job_id: int, error: str, max_attempts: int) -> bool:
        """Bump attempts; returns True if the job is permanently failed."""
        conn = self._conn()
        now = time.time()
        with self._write_lock:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT attempts FROM jobs WHERE id=?",
                               (job_id,)).fetchone()
            attempts = (row["attempts"] if row else 0) + 1
            dead = attempts >= max_attempts
            conn.execute(
                "UPDATE jobs SET status=?, attempts=?, error=?, lease_at=0, updated=? "
                "WHERE id=?",
                ("failed" if dead else "pending", attempts, error[:500], now, job_id),
            )
            conn.execute("COMMIT")
        return dead

    def release(self, job_id: int, error: str = "") -> None:
        """Put a job straight back in the queue without burning an attempt."""
        conn = self._conn()
        with self._write_lock:
            conn.execute(
                "UPDATE jobs SET status='pending', lease_at=0, error=?, updated=? "
                "WHERE id=?", (error[:500], time.time(), job_id))

    def reset_running(self) -> int:
        conn = self._conn()
        with self._write_lock:
            cur = conn.execute(
                "UPDATE jobs SET status='pending', lease_at=0 WHERE status='running'")
        return cur.rowcount or 0

    def reset_failed(self) -> int:
        conn = self._conn()
        with self._write_lock:
            cur = conn.execute(
                "UPDATE jobs SET status='pending', attempts=0, lease_at=0 "
                "WHERE status='failed'")
        return cur.rowcount or 0

    # ------------------------------------------------------------------ #
    def stats(self) -> dict[str, int]:
        conn = self._conn()
        rows = conn.execute("SELECT status, COUNT(*) c FROM jobs GROUP BY status")
        out = {r["status"]: r["c"] for r in rows}
        out["total"] = conn.execute("SELECT COUNT(*) c FROM jobs").fetchone()["c"]
        return out

    def iter_results(self, chunk: int = 5_000) -> Iterator[sqlite3.Row]:
        conn = self._conn()
        cur = conn.execute(
            "SELECT query, answer, sources, chars, took_ms, scraped_at "
            "FROM results ORDER BY job_id")
        while True:
            rows = cur.fetchmany(chunk)
            if not rows:
                return
            yield from rows


def read_queries(path: str | Path) -> Iterator[str]:
    """Stream a query file (one per line) without loading 5 lakh rows into RAM."""
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if line:
                yield line
