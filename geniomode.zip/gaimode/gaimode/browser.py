"""Browser lifecycle: engine selection, stealth patches, contexts, proxies."""
from __future__ import annotations

import asyncio
import itertools
import random
from pathlib import Path
from typing import Any, Optional

from playwright.async_api import Browser, BrowserContext, Playwright, async_playwright

# ---------------------------------------------------------------------------

CHROMIUM_ARGS = [
    "--no-sandbox",
    "--disable-dev-shm-usage",
    "--disable-blink-features=AutomationControlled",
    "--disable-features=IsolateOrigins,site-per-process,AutomationControlled,"
    "TranslateUI,BlinkGenPropertyTrees",
    "--disable-background-timer-throttling",
    "--disable-backgrounding-occluded-windows",
    "--disable-renderer-backgrounding",
    "--disable-infobars",
    "--no-first-run",
    "--no-default-browser-check",
    "--mute-audio",
    "--disable-gpu",
    "--window-size=1366,850",
]

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36",
]

VIEWPORTS = [
    {"width": 1366, "height": 768},
    {"width": 1440, "height": 900},
    {"width": 1536, "height": 864},
    {"width": 1280, "height": 800},
    {"width": 1920, "height": 1080},
]

# Patches the handful of signals a plain Playwright Chromium leaks.
STEALTH_JS = r"""
Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
try { delete Object.getPrototypeOf(navigator).webdriver; } catch (e) {}

window.chrome = window.chrome || {};
window.chrome.runtime = window.chrome.runtime || {};
window.chrome.csi = window.chrome.csi || function () { return {}; };
window.chrome.loadTimes = window.chrome.loadTimes || function () { return {}; };

Object.defineProperty(navigator, 'plugins', {
  get: () => [1, 2, 3, 4, 5].map(i => ({ name: 'Plugin ' + i, filename: 'p' + i }))
});
Object.defineProperty(navigator, 'languages', {get: () => ['en-US', 'en']});
Object.defineProperty(navigator, 'hardwareConcurrency', {get: () => 8});
Object.defineProperty(navigator, 'deviceMemory', {get: () => 8});
Object.defineProperty(navigator, 'maxTouchPoints', {get: () => 0});

const origQuery = navigator.permissions && navigator.permissions.query;
if (origQuery) {
  navigator.permissions.query = (p) =>
    p && p.name === 'notifications'
      ? Promise.resolve({ state: Notification.permission })
      : origQuery.call(navigator.permissions, p);
}

const getParameter = WebGLRenderingContext.prototype.getParameter;
WebGLRenderingContext.prototype.getParameter = function (p) {
  if (p === 37445) return 'Intel Inc.';
  if (p === 37446) return 'Intel Iris OpenGL Engine';
  return getParameter.call(this, p);
};

Object.defineProperty(screen, 'colorDepth', {get: () => 24});
"""

BLOCKED_RESOURCE_TYPES = {"image", "media", "font"}
BLOCKED_URL_PARTS = (
    "googlesyndication.com", "doubleclick.net", "google-analytics.com",
    "googletagmanager.com", "/gen_204", "/log?", "/client_204",
    "fonts.gstatic.com", "/images/branding/",
)


class ProxyPool:
    """Round-robin proxy list with temporary banning of burned endpoints."""

    def __init__(self, path: Optional[Path]):
        self.proxies: list[str] = []
        if path and Path(path).exists():
            for line in Path(path).read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    self.proxies.append(line)
        random.shuffle(self.proxies)
        self._cycle = itertools.cycle(self.proxies) if self.proxies else None
        self._banned: dict[str, float] = {}
        self._lock = asyncio.Lock()

    def __bool__(self) -> bool:
        return bool(self.proxies)

    async def next(self) -> Optional[dict[str, str]]:
        if not self._cycle:
            return None
        loop = asyncio.get_event_loop()
        async with self._lock:
            for _ in range(len(self.proxies) * 2):
                raw = next(self._cycle)
                until = self._banned.get(raw, 0)
                if until <= loop.time():
                    return self._parse(raw)
            return self._parse(random.choice(self.proxies))

    async def ban(self, proxy: Optional[dict[str, str]], seconds: float = 300.0) -> None:
        if not proxy:
            return
        loop = asyncio.get_event_loop()
        async with self._lock:
            for raw in self.proxies:
                if proxy["server"].split("//")[-1] in raw:
                    self._banned[raw] = loop.time() + seconds

    @staticmethod
    def _parse(raw: str) -> dict[str, str]:
        # http://user:pass@host:port  |  host:port:user:pass  |  http://host:port
        if "://" not in raw:
            parts = raw.split(":")
            if len(parts) == 4:
                host, port, user, pwd = parts
                return {"server": f"http://{host}:{port}", "username": user,
                        "password": pwd}
            return {"server": f"http://{raw}"}
        scheme, rest = raw.split("://", 1)
        if "@" in rest:
            creds, hostport = rest.rsplit("@", 1)
            user, _, pwd = creds.partition(":")
            return {"server": f"{scheme}://{hostport}", "username": user,
                    "password": pwd}
        return {"server": raw}


class BrowserManager:
    """Owns one browser process and hands out freshly fingerprinted contexts."""

    def __init__(self, settings):
        self.s = settings
        self._pw: Optional[Playwright] = None
        self._browser: Optional[Browser] = None
        self._cm: Any = None  # camoufox async context manager
        self.jobs_served = 0

    # ------------------------------------------------------------------ #
    async def start(self, proxy: Optional[dict[str, str]] = None) -> None:
        engine = self.s.engine.lower()
        if engine == "camoufox":
            try:
                from camoufox.async_api import AsyncCamoufox
            except ImportError as exc:  # pragma: no cover
                raise RuntimeError(
                    "engine=camoufox but camoufox is not installed. "
                    "Run: pip install 'camoufox[geoip]' && python -m camoufox fetch\n"
                    "Or set GAIM_ENGINE=chromium"
                ) from exc
            self._cm = AsyncCamoufox(
                headless=self.s.headless,
                humanize=True,
                locale="en-US",
                os=["windows", "macos", "linux"],
                proxy=proxy,
                geoip=bool(proxy),
                args=["--disable-dev-shm-usage"],
            )
            self._browser = await self._cm.__aenter__()
            return

        self._pw = await async_playwright().start()
        launch_kwargs: dict[str, Any] = {
            "headless": self.s.headless,
            "proxy": proxy,
        }
        if engine == "firefox":
            self._browser = await self._pw.firefox.launch(**launch_kwargs)
        else:
            self._browser = await self._pw.chromium.launch(
                args=CHROMIUM_ARGS,
                chromium_sandbox=False,
                **launch_kwargs,
            )

    async def close(self) -> None:
        try:
            if self._cm is not None:
                await self._cm.__aexit__(None, None, None)
                self._cm = None
                self._browser = None
            elif self._browser is not None:
                await self._browser.close()
                self._browser = None
        except Exception:
            pass
        try:
            if self._pw is not None:
                await self._pw.stop()
                self._pw = None
        except Exception:
            pass

    # ------------------------------------------------------------------ #
    async def new_context(self) -> BrowserContext:
        if self._browser is None:
            raise RuntimeError("BrowserManager.start() was not called")

        kwargs: dict[str, Any] = {
            "locale": "en-US",
            "timezone_id": random.choice(
                ["America/New_York", "America/Chicago", "America/Los_Angeles",
                 "Europe/London"]),
            "viewport": random.choice(VIEWPORTS),
            "java_script_enabled": True,
            "ignore_https_errors": True,
            "service_workers": "block",
        }
        if self.s.engine.lower() == "chromium":
            kwargs["user_agent"] = random.choice(USER_AGENTS)
            kwargs["extra_http_headers"] = {
                "Accept-Language": "en-US,en;q=0.9",
                "Sec-Ch-Ua": '"Chromium";v="140", "Not:A-Brand";v="24", "Google Chrome";v="140"',
                "Sec-Ch-Ua-Mobile": "?0",
                "Sec-Ch-Ua-Platform": '"Windows"',
                "Upgrade-Insecure-Requests": "1",
            }

        ctx = await self._browser.new_context(**kwargs)
        ctx.set_default_timeout(self.s.nav_timeout_ms)
        ctx.set_default_navigation_timeout(self.s.nav_timeout_ms)

        if self.s.engine.lower() == "chromium":
            await ctx.add_init_script(STEALTH_JS)

        # Pre-accept consent so the EU/IN interstitial never appears.
        await ctx.add_cookies([
            {"name": "SOCS", "value": "CAESHAgBEhIaAB",
             "domain": ".google.com", "path": "/"},
            {"name": "CONSENT", "value": f"YES+cb.{random.randint(20210000, 20250101)}-04-p0.en+FX+{random.randint(100, 999)}",
             "domain": ".google.com", "path": "/"},
        ])

        if self.s.block_assets:
            await ctx.route("**/*", _router)

        return ctx


async def _router(route, request) -> None:
    try:
        if request.resource_type in BLOCKED_RESOURCE_TYPES:
            await route.abort()
            return
        url = request.url
        if any(p in url for p in BLOCKED_URL_PARTS):
            await route.abort()
            return
        await route.continue_()
    except Exception:
        try:
            await route.continue_()
        except Exception:
            pass
