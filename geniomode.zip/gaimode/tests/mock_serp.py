"""Tiny local server that imitates the Google AI Mode page shape.

Used to test extraction + streaming-settle logic without hitting Google.
Serves three variants:
    /search?q=...            -> normal streamed AI answer
    /sorry/index             -> block page
    /empty                   -> page with no AI container
"""
from __future__ import annotations

import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

PAGE = """<!doctype html><html><head><title>q - Google Search</title></head>
<body>
<div id="searchform"><input name="q" value="__Q__"></div>
<div role="main" id="main">
  <div class="chrome">People also ask</div>
  <div data-subtree="aimc"><div id="ans"></div>
    <div class="cites">
      <a href="https://en.wikipedia.org/wiki/Sky">Wikipedia - Sky</a>
      <a href="https://www.google.com/search?q=x">internal google</a>
      <a href="/url?q=https%3A%2F%2Fnasa.gov%2Fblue&amp;sa=U">NASA</a>
      <a href="https://nasa.gov/blue">NASA dup</a>
    </div>
  </div>
  <div class="chrome">Related searches</div>
</div>
<script>
const CH = ["## Short answer\\n", "The sky looks blue because of Rayleigh scattering. ",
 "Shorter wavelengths of light are scattered far more strongly by the gas molecules in the atmosphere than longer red wavelengths. ",
 "At sunrise and sunset the light travels through much more atmosphere, so most of the blue is scattered away and the remaining light appears red or orange. ",
 "This effect scales as one over wavelength to the fourth power, which is why violet and blue dominate the scattered light we see overhead on a clear day."];
let i = 0;
const el = document.getElementById('ans');
const t = setInterval(() => {
  if (i >= CH.length) { clearInterval(t);
    const ta = document.createElement('textarea');
    ta.setAttribute('aria-label', 'Ask a follow up'); document.body.appendChild(ta);
    return; }
  const p = document.createElement('p'); p.textContent = CH[i++]; el.appendChild(p);
}, 400);
</script>
</body></html>"""

SORRY = """<!doctype html><html><body><h1>About this page</h1>
<p>Our systems have detected unusual traffic from your computer network.</p>
<div id="g-recaptcha"></div></body></html>"""

EMPTY = "<!doctype html><html><body><div role='main'>hi</div></body></html>"


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):  # noqa: N802
        p = urlparse(self.path)
        if "/sorry/" in p.path:
            body, code = SORRY, 200
        elif p.path == "/empty":
            body, code = EMPTY, 200
        else:
            q = parse_qs(p.query).get("q", ["?"])[0]
            body, code = PAGE.replace("__Q__", q), 200
        raw = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def log_message(self, *a):  # silence
        pass


def serve(port: int = 8099) -> ThreadingHTTPServer:
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv
