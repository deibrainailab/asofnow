"""Runs the real worker pool against the mock SERP to verify orchestration."""
import asyncio, sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from gaimode import worker
from gaimode.config import Settings
from gaimode.db import JobStore
from gaimode.worker import Scraper
from mock_serp import serve

PORT = 8098
serve(PORT)
tmp = Path(tempfile.mkdtemp())
s = Settings()
s.db_path = tmp/"jobs.db"; s.out_dir = tmp; s.log_dir = tmp; s.debug_dir = tmp; s.profile_dir = tmp
s.engine="chromium"; s.headless=True; s.workers=3; s.context_max_jobs=2
s.answer_timeout_ms=20000; s.settle_ms=1000; s.min_delay_s=0; s.max_delay_s=0.2
s.proxy_file = tmp/"none.txt"
s.ensure_dirs()
worker.build_url = lambda q, st: f"http://127.0.0.1:{PORT}/search?q={q}&udm=50"

store = JobStore(s.db_path)
store.add_queries([f"test query number {i}" for i in range(9)])
import logging; logging.basicConfig(level=logging.INFO, format="%(message)s")
asyncio.run(Scraper(store, s).run())
st = store.stats()
print("STATS:", st)
rows = list(store.iter_results())
assert st.get("done") == 9, st
assert all(len(r["answer"]) > 300 for r in rows)
assert st.get("pending", 0) == 0 and st.get("running", 0) == 0
print(f"PASS  pool drained 9/9 jobs, avg {sum(r['chars'] for r in rows)//9} chars")
