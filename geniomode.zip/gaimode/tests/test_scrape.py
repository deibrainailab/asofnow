"""End-to-end test of the browser + extraction + settle logic (no Google needed).

    python tests/test_scrape.py
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from gaimode import worker  # noqa: E402
from gaimode.browser import BrowserManager  # noqa: E402
from gaimode.config import Settings  # noqa: E402
from gaimode.worker import Blocked, NoAnswer, scrape_one  # noqa: E402
from mock_serp import serve  # noqa: E402

PORT = 8099


async def main() -> int:
    serve(PORT)
    s = Settings()
    s.engine = "chromium"
    s.headless = True
    s.answer_timeout_ms = 20_000
    s.settle_ms = 1_200
    s.ensure_dirs()

    # redirect the scraper at our mock SERP
    worker.build_url = lambda q, st: f"http://127.0.0.1:{PORT}/search?q={q}&udm=50"

    mgr = BrowserManager(s)
    await mgr.start(None)
    ok = True
    try:
        ctx = await mgr.new_context()
        page = await ctx.new_page()

        # --- 1. happy path, streamed answer ---------------------------------
        res = await scrape_one(page, "why is the sky blue", s)
        assert "Rayleigh scattering" in res.answer, res.answer
        assert "one over wavelength" in res.answer, "did not wait for full stream"
        assert res.selector == 'div[data-subtree="aimc"]', res.selector
        urls = [x["url"] for x in res.sources]
        assert "https://en.wikipedia.org/wiki/Sky" in urls, urls
        assert "https://nasa.gov/blue" in urls, urls          # /url?q= unwrapped
        assert len([u for u in urls if u == "https://nasa.gov/blue"]) == 1, "dedupe"
        assert not any("google.com" in u for u in urls), urls  # internal filtered
        print(f"PASS  streamed answer   {len(res.answer)} chars, "
              f"{len(res.sources)} sources, {res.took_ms} ms")

        # --- 2. block page detection ----------------------------------------
        worker.build_url = lambda q, st: f"http://127.0.0.1:{PORT}/sorry/index"
        try:
            await scrape_one(page, "blocked", s)
            print("FAIL  block page was not detected"); ok = False
        except Blocked as e:
            print(f"PASS  block detected    ({e})")

        # --- 3. no-answer page ----------------------------------------------
        worker.build_url = lambda q, st: f"http://127.0.0.1:{PORT}/empty"
        s.answer_timeout_ms = 4_000
        try:
            await scrape_one(page, "empty", s)
            print("FAIL  empty page returned an answer"); ok = False
        except NoAnswer as e:
            print(f"PASS  no-answer raised  ({e})")

        # --- 4. stealth sanity ----------------------------------------------
        wd = await page.evaluate("() => navigator.webdriver")
        assert wd is None, f"navigator.webdriver leaked: {wd}"
        print("PASS  navigator.webdriver hidden")

    finally:
        await mgr.close()

    print("\nALL TESTS PASSED" if ok else "\nSOME TESTS FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
