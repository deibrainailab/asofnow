"""Regression tests for block classification + consent recovery (real browser)."""
import asyncio, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from gaimode import worker
from gaimode.browser import BrowserManager
from gaimode.config import Settings
from gaimode.extract import BlockKind
from gaimode.worker import Blocked, scrape_one
from mock_serp import serve

PORT = 8097

async def main():
    serve(PORT)
    s = Settings(); s.engine="chromium"; s.headless=True
    s.answer_timeout_ms=20000; s.settle_ms=1000; s.ensure_dirs()
    mgr = BrowserManager(s); await mgr.start(None)
    ok = True
    try:
        ctx = await mgr.new_context(); page = await ctx.new_page()

        # 1. THE BUG: normal SERP with "recaptcha" in a script bundle
        worker.build_url = lambda q, st: f"http://127.0.0.1:{PORT}/trap"
        try:
            res = await scrape_one(page, "trap", s)
            print(f"PASS  no false positive on 'recaptcha' in JS ({len(res.answer)} chars)")
        except Blocked as e:
            print(f"FAIL  false positive: {e}"); ok = False

        # 2. consent wall -> auto-accepted, then answer extracted
        worker.build_url = lambda q, st: f"http://127.0.0.1:{PORT}/cwall"
        try:
            res = await scrape_one(page, "consent", s)
            print(f"PASS  consent wall auto-cleared, got {len(res.answer)} chars")
        except Blocked as e:
            print(f"FAIL  consent not cleared: {e}"); ok = False

        # 3. real sorry page -> SORRY, and is_ban must be True
        worker.build_url = lambda q, st: f"http://127.0.0.1:{PORT}/sorry/index"
        try:
            await scrape_one(page, "x", s); print("FAIL  sorry not detected"); ok=False
        except Blocked as e:
            good = e.kind == BlockKind.SORRY and e.is_ban
            print(f"{'PASS' if good else 'FAIL'}  sorry -> kind={e.kind} is_ban={e.is_ban}")
            ok &= good
    finally:
        await mgr.close()
    print("\nALL PASSED" if ok else "\nFAILURES"); return 0 if ok else 1

raise SystemExit(asyncio.run(main()))
