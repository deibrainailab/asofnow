"""Tiny local server that imitates the Google AI Mode page shape.

Used to test extraction + streaming-settle logic without hitting Google.
Serves three variants:
    /search?q=...            -> normal streamed AI answer
    /sorry/index             -> block page
    /empty                   -> page with no AI container
"""
from __future__ import annotations

import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

PAGE = """<!doctype html><html><head><title>q - Google Search</title></head>
<body>
<div id="searchform"><input name="q" value="__Q__"></div>
<div role="main" id="main">
  <div class="chrome">People also ask</div>
  <div data-subtree="aimc"><div id="ans"></div>
    <div class="cites">
      <a href="https://en.wikipedia.org/wiki/Sky">Wikipedia - Sky</a>
      <a href="https://www.google.com/search?q=x">internal google</a>
      <a href="/url?q=https%3A%2F%2Fnasa.gov%2Fblue&amp;sa=U">NASA</a>
      <a href="https://nasa.gov/blue">NASA dup</a>
    </div>
  </div>
  <div class="chrome">Related searches</div>
</div>
<script>
const CH = ["## Short answer\\n", "The sky looks blue because of Rayleigh scattering. ",
 "Shorter wavelengths of light are scattered far more strongly by the gas molecules in the atmosphere than longer red wavelengths. ",
 "At sunrise and sunset the light travels through much more atmosphere, so most of the blue is scattered away and the remaining light appears red or orange. ",
 "This effect scales as one over wavelength to the fourth power, which is why violet and blue dominate the scattered light we see overhead on a clear day."];
let i = 0;
const el = document.getElementById('ans');
const t = setInterval(() => {
  if (i >= CH.length) { clearInterval(t);
    const ta = document.createElement('textarea');
    ta.setAttribute('aria-label', 'Ask a follow up'); document.body.appendChild(ta);
    return; }
  const p = document.createElement('p'); p.textContent = CH[i++]; el.appendChild(p);
}, 400);
</script>
</body></html>"""

SORRY = """<!doctype html><html><body><h1>About this page</h1>
<p>Our systems have detected unusual traffic from your computer network.</p>
<div id="g-recaptcha"></div></body></html>"""

EMPTY = "<!doctype html><html><body><div role='main'>hi</div></body></html>"

# Cookie wall: serves the wall until /consent_accept is hit, then the real page.
CONSENT = """<!doctype html><html><head><title>Before you continue to Google</title></head>
<body><h1>Before you continue to Google</h1>
<p>We use cookies and data to deliver and maintain Google services.</p>
<form action="/consent_accept"><button id="L2AGLb">Accept all</button></form>
</body></html>"""

# A NORMAL serp whose inline JS mentions recaptcha -> must NOT be flagged.
TRAP = PAGE.replace("<script>", "<script>var recaptcha_cfg={'g-recaptcha':1};</script><script>", 1)



CONSENT_CLEARED = False


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):  # noqa: N802
        p = urlparse(self.path)
        global CONSENT_CLEARED
        if p.path == "/consent_accept":
            CONSENT_CLEARED = True
            self.send_response(302); self.send_header("Location", "/search?q=ok")
            self.end_headers(); return
        if p.path == "/cwall" and not CONSENT_CLEARED:
            body, code = CONSENT, 200
        elif p.path == "/cwall":
            body, code = PAGE.replace("__Q__", "ok"), 200
        elif p.path == "/short":
            body, code = SHORT.replace("__Q__", parse_qs(p.query).get("q",["?"])[0]), 200
        elif p.path == "/trap":
            body, code = TRAP.replace("__Q__", "trap"), 200
        elif "/sorry/" in p.path:
            body, code = SORRY, 200
        elif p.path == "/empty":
            body, code = EMPTY, 200
        else:
            q = parse_qs(p.query).get("q", ["?"])[0]
            body, code = PAGE.replace("__Q__", q), 200
        raw = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.end_headers()
        self.wfile.write(raw)

    def log_message(self, *a):  # silence
        pass


SHORT = """<!doctype html><html><head><title>q - Google Search</title></head><body>
<div role="main" id="main">
  <div data-subtree="aimc">
    <span>AI Mode reply for __Q__</span>
    <p>No. Would you like to know the main differences between Apple and Google?</p>
    <div aria-live="polite">Copied to clipboard</div>
    <div role="status">Failed to copy to clipboard.</div>
    <button>Try again</button>
    <div aria-hidden="true">AI responses may include mistakes.</div>
  </div>
</div></body></html>"""


def serve(port: int = 8099) -> ThreadingHTTPServer:
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv
