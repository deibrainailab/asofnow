"""Command line entry point.

    python -m gaimode load    queries.txt
    python -m gaimode run     [--workers 6] [--engine chromium]
    python -m gaimode stats
    python -m gaimode export  results.jsonl
    python -m gaimode test    "your query here"
    python -m gaimode reset   [--failed] [--running]
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import signal
import sys
from pathlib import Path

from .config import SETTINGS
from .db import JobStore, read_queries


def setup_logging(s) -> None:
    s.ensure_dirs()
    fmt = "%(asctime)s %(levelname)-7s %(message)s"
    logging.basicConfig(
        level=logging.INFO, format=fmt, datefmt="%H:%M:%S",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(s.log_dir / "gaimode.log", encoding="utf-8"),
        ],
    )
    logging.getLogger("asyncio").setLevel(logging.WARNING)


# --------------------------------------------------------------------------- #

def cmd_load(args, s) -> int:
    store = JobStore(s.db_path)
    n = store.add_queries(read_queries(args.file))
    st = store.stats()
    print(f"loaded {n:,} new queries  |  total in queue: {st['total']:,}")
    return 0


def cmd_stats(args, s) -> int:
    st = JobStore(s.db_path).stats()
    total = st.pop("total", 0)
    print(f"total    {total:,}")
    for k in ("pending", "running", "done", "failed"):
        print(f"{k:<9}{st.get(k, 0):,}")
    if total:
        print(f"progress {st.get('done', 0) / total * 100:.2f}%")
    return 0


def cmd_reset(args, s) -> int:
    store = JobStore(s.db_path)
    if args.running or not args.failed:
        print(f"requeued {store.reset_running():,} stuck 'running' jobs")
    if args.failed:
        print(f"requeued {store.reset_failed():,} failed jobs")
    return 0


def cmd_export(args, s) -> int:
    store = JobStore(s.db_path)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with out.open("w", encoding="utf-8") as fh:
        for r in store.iter_results():
            fh.write(json.dumps({
                "query": r["query"],
                "answer": r["answer"],
                "sources": json.loads(r["sources"]),
                "chars": r["chars"],
                "took_ms": r["took_ms"],
                "scraped_at": r["scraped_at"],
            }, ensure_ascii=False) + "\n")
            n += 1
    print(f"exported {n:,} rows -> {out}")
    return 0


def cmd_run(args, s) -> int:
    from .worker import Scraper

    if args.workers:
        s.workers = args.workers
    if args.engine:
        s.engine = args.engine
    if args.no_headless:
        s.headless = False

    store = JobStore(s.db_path)
    requeued = store.reset_running()
    if requeued:
        logging.info("requeued %d stale running jobs", requeued)

    st = store.stats()
    logging.info("queue: %s", st)
    if not st.get("pending"):
        logging.warning("nothing pending - load queries first")
        return 0

    scraper = Scraper(store, s)
    logging.info("engine=%s workers=%d proxies=%d headless=%s",
                 s.engine, s.workers, len(scraper.proxies.proxies), s.headless)

    async def main() -> None:
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(
                    sig, lambda: (logging.warning("shutting down..."),
                                  scraper.stop()))
            except NotImplementedError:
                pass
        await scraper.run()

    asyncio.run(main())
    return 0


def _diagnose(args, s) -> int:
    from .diagnose import cmd_diagnose
    return cmd_diagnose(args, s)


def cmd_test(args, s) -> int:
    from .browser import BrowserManager, ProxyPool
    from .worker import scrape_one

    if args.engine:
        s.engine = args.engine
    if args.no_headless:
        s.headless = False
    s.save_debug_html = True

    async def main() -> int:
        pool = ProxyPool(s.proxy_file)
        proxy = await pool.next()
        mgr = BrowserManager(s)
        await mgr.start(proxy)
        try:
            ctx = await mgr.new_context()
            page = await ctx.new_page()
            res = await scrape_one(page, args.query, s)
            print("=" * 70)
            print(f"selector : {res.selector}")
            print(f"took     : {res.took_ms} ms")
            print(f"chars    : {len(res.answer)}")
            print("=" * 70)
            print(res.answer[:3000])
            print("=" * 70)
            for src in res.sources[:15]:
                print(f"  - {src['url']}")
            return 0
        finally:
            await mgr.close()

    return asyncio.run(main())


# --------------------------------------------------------------------------- #

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser("gaimode", description="Google AI Mode scraper")
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("load", help="bulk-load a queries.txt into the queue")
    a.add_argument("file")
    a.set_defaults(fn=cmd_load)

    a = sub.add_parser("run", help="start scraping")
    a.add_argument("--workers", type=int)
    a.add_argument("--engine", choices=["camoufox", "chromium", "firefox"])
    a.add_argument("--no-headless", action="store_true")
    a.set_defaults(fn=cmd_run)

    a = sub.add_parser("test", help="scrape a single query and print it")
    a.add_argument("query")
    a.add_argument("--engine", choices=["camoufox", "chromium", "firefox"])
    a.add_argument("--no-headless", action="store_true")
    a.set_defaults(fn=cmd_test)

    a = sub.add_parser("diagnose", help="find out WHY you are being blocked")
    a.add_argument("query", nargs="?", default="why is the sky blue")
    a.add_argument("--engine", choices=["camoufox", "chromium", "firefox"])
    a.add_argument("--no-headless", action="store_true")
    a.add_argument("--no-proxy", action="store_true",
                   help="ignore proxies.txt and test the raw server IP")
    a.set_defaults(fn=_diagnose)

    a = sub.add_parser("stats", help="queue progress")
    a.set_defaults(fn=cmd_stats)

    a = sub.add_parser("export", help="dump results to JSONL")
    a.add_argument("out", nargs="?", default="results.jsonl")
    a.set_defaults(fn=cmd_export)

    a = sub.add_parser("reset", help="requeue stuck/failed jobs")
    a.add_argument("--failed", action="store_true")
    a.add_argument("--running", action="store_true")
    a.set_defaults(fn=cmd_reset)

    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    setup_logging(SETTINGS)
    return args.fn(args, SETTINGS)


if __name__ == "__main__":
    raise SystemExit(main())
