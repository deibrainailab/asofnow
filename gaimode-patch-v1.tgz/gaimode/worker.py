"""Scrape logic + the async worker pool."""
from __future__ import annotations

import asyncio
import logging
import random
import time
import urllib.parse
from dataclasses import dataclass
from typing import Optional

from playwright.async_api import BrowserContext, Error as PWError, Page, TimeoutError as PWTimeout

from .browser import BrowserManager, ProxyPool
from .config import Settings
from .db import JobStore
from .extract import (BlockKind, CONTAINER_SELECTORS, DETECT_JS, EXTRACT_JS,
                      classify, clean_answer, looks_blocked)

log = logging.getLogger("gaimode")


class Blocked(Exception):
    """Google served a CAPTCHA / sorry / consent interstitial."""

    def __init__(self, kind: str, detail: str = ""):
        self.kind = kind
        super().__init__(f"{kind}{': ' + detail if detail else ''}")

    @property
    def is_ban(self) -> bool:
        """True = the IP is burned. False = recoverable (consent wall etc)."""
        return self.kind in (BlockKind.SORRY, BlockKind.RECAPTCHA, BlockKind.HTTP)


class NoAnswer(Exception):
    """Page loaded but no AI answer could be extracted."""


@dataclass
class ScrapeResult:
    query: str
    answer: str
    sources: list[dict]
    selector: str
    took_ms: int


def build_url(query: str, s: Settings) -> str:
    params = {
        "q": query,
        "udm": "50",
        "aep": "11",
        "hl": s.hl,
        "gl": s.gl,
    }
    return f"https://{s.domain}/search?" + urllib.parse.urlencode(
        params, quote_via=urllib.parse.quote_plus)


CONSENT_SELECTORS = (
    'button#L2AGLb',                       # "Accept all" on google.com
    'button#W0wltc',                       # "Reject all"
    'div[role="dialog"] button:has-text("Accept all")',
    'form[action*="consent"] button[jsname]',
    'button:has-text("Accept all")',
    'button:has-text("I agree")',
    'button:has-text("Agree to all")',
    'input[type="submit"][value*="Accept"]',
)


async def _dismiss_consent(page: Page) -> bool:
    """Click through the cookie wall. Returns True if something was clicked."""
    for sel in CONSENT_SELECTORS:
        try:
            loc = page.locator(sel).first
            if await loc.count() and await loc.is_visible(timeout=700):
                await loc.click(timeout=3000, no_wait_after=True)
                await page.wait_for_timeout(1200)
                return True
        except Exception:
            continue
    # Last resort: submit the consent form directly.
    try:
        n = await page.evaluate(
            """() => { const f = document.querySelector('form[action*="consent"]');
                       if (f) { f.submit(); return 1; } return 0; }""")
        if n:
            await page.wait_for_timeout(1500)
            return True
    except Exception:
        pass
    return False


async def warmup(page: Page, s: Settings) -> None:
    """Visit the Google homepage once per context to pick up NID/consent cookies.

    Hitting /search?udm=50 as the very first request from a cold cookie jar is a
    strong bot signal and is a common cause of instant /sorry/ redirects.
    """
    try:
        await page.goto(f"https://{s.domain}/?hl={s.hl}&gl={s.gl}",
                        wait_until="domcontentloaded", timeout=s.nav_timeout_ms)
        await page.wait_for_timeout(random.randint(400, 1100))
        probe = await page.evaluate(DETECT_JS)
        if classify(probe) == BlockKind.CONSENT:
            await _dismiss_consent(page)
        # a little human noise
        await page.mouse.move(random.randint(200, 900), random.randint(150, 600))
    except Exception as exc:
        log.debug("warmup skipped: %s", exc)


async def scrape_one(page: Page, query: str, s: Settings) -> ScrapeResult:
    """Load AI Mode for `query` and wait until the streamed answer settles."""
    t0 = time.monotonic()
    url = build_url(query, s)

    try:
        resp = await page.goto(url, wait_until="domcontentloaded",
                               timeout=s.nav_timeout_ms)
    except PWTimeout as exc:
        raise NoAnswer(f"navigation timeout: {exc}") from exc

    status = resp.status if resp else 0

    # ---- classify the landing page ----------------------------------------
    try:
        probe = await page.evaluate(DETECT_JS)
    except PWError:
        probe = {}
    kind = classify(probe, status)

    if kind == BlockKind.CONSENT:
        # Recoverable: accept cookies, then re-request the search URL once.
        if await _dismiss_consent(page):
            try:
                await page.goto(url, wait_until="domcontentloaded",
                                timeout=s.nav_timeout_ms)
                probe = await page.evaluate(DETECT_JS)
                kind = classify(probe, 200)
            except PWError as exc:
                raise Blocked(BlockKind.CONSENT, str(exc)[:120]) from exc
        if kind == BlockKind.CONSENT:
            raise Blocked(BlockKind.CONSENT, "could not clear cookie wall")

    if kind:
        raise Blocked(kind, (probe.get("title") or "")[:120])

    # ---- poll until the streaming answer stops growing --------------------
    deadline = time.monotonic() + s.answer_timeout_ms / 1000
    last_len, stable_since = -1, None
    data: dict = {}

    while time.monotonic() < deadline:
        try:
            data = await page.evaluate(EXTRACT_JS, CONTAINER_SELECTORS)
        except PWError:
            data = {}
        text = clean_answer((data or {}).get("text") or "", query)
        cur = len(text)

        if cur >= s.min_answer_chars and cur == last_len:
            if stable_since is None:
                stable_since = time.monotonic()
            elif (time.monotonic() - stable_since) * 1000 >= s.settle_ms:
                break
        else:
            stable_since = None
        last_len = cur

        await page.wait_for_timeout(s.poll_ms)

    text = clean_answer((data or {}).get("text") or "", query)
    if len(text) < s.min_answer_chars:
        # A challenge can appear *after* load; re-classify before calling it a miss.
        try:
            probe = await page.evaluate(DETECT_JS)
        except PWError:
            probe = {}
        kind = classify(probe)
        if kind:
            raise Blocked(kind, "appeared after load")
        try:
            html = await page.content()
        except PWError:
            html = ""
        if s.save_debug_html:
            s.ensure_dirs()
            fn = s.debug_dir / f"noanswer_{abs(hash(query)) % 10**10}.html"
            fn.write_text(html[:2_000_000], encoding="utf-8")
        raise NoAnswer(f"answer too short ({len(text)} chars)")

    return ScrapeResult(
        query=query,
        answer=text,
        sources=(data.get("sources") or [])[:60],
        selector=data.get("selector") or "?",
        took_ms=int((time.monotonic() - t0) * 1000),
    )


# --------------------------------------------------------------------------- #

class Stats:
    def __init__(self) -> None:
        self.done = 0
        self.failed = 0
        self.blocked = 0
        self.by_kind: dict[str, int] = {}
        self.start = time.monotonic()

    def line(self, pending: int) -> str:
        el = max(time.monotonic() - self.start, 1e-6)
        rate = self.done / el
        eta = pending / rate if rate > 0 else float("inf")
        kinds = " ".join(f"{k}={v}" for k, v in sorted(self.by_kind.items()))
        return (f"done={self.done} failed={self.failed} blocked={self.blocked} "
                f"pending={pending} | {rate*60:.1f} q/min | "
                f"eta={eta/3600:.1f}h" + (f" | {kinds}" if kinds else ""))


class Scraper:
    def __init__(self, store: JobStore, s: Settings):
        self.store = store
        self.s = s
        self.proxies = ProxyPool(s.proxy_file)
        self.stats = Stats()
        self._stop = asyncio.Event()
        self._cooldown_until = 0.0

    def stop(self) -> None:
        self._stop.set()

    async def _respect_cooldown(self) -> None:
        loop = asyncio.get_event_loop()
        while loop.time() < self._cooldown_until and not self._stop.is_set():
            await asyncio.sleep(min(2.0, self._cooldown_until - loop.time()))

    def _trigger_cooldown(self) -> None:
        loop = asyncio.get_event_loop()
        self._cooldown_until = max(self._cooldown_until,
                                   loop.time() + self.s.block_cooldown_s)

    # ------------------------------------------------------------------ #
    async def _worker(self, wid: int) -> None:
        mgr: Optional[BrowserManager] = None
        ctx: Optional[BrowserContext] = None
        page: Optional[Page] = None
        proxy = None
        ctx_jobs = 0
        browser_jobs = 0

        async def teardown() -> None:
            nonlocal ctx, page, mgr
            for closer in (page, ctx):
                try:
                    if closer:
                        await closer.close()
                except Exception:
                    pass
            page, ctx = None, None
            if mgr:
                await mgr.close()
                mgr = None

        try:
            while not self._stop.is_set():
                await self._respect_cooldown()

                rows = await asyncio.to_thread(self.store.claim, 1)
                if not rows:
                    stats = await asyncio.to_thread(self.store.stats)
                    if stats.get("pending", 0) == 0 and stats.get("running", 0) == 0:
                        return  # queue drained
                    await asyncio.sleep(2.0)
                    continue

                job = rows[0]
                job_id, query = job["id"], job["query"]

                # (re)build browser / context as needed
                if mgr is None or browser_jobs >= self.s.browser_max_jobs:
                    await teardown()
                    proxy = await self.proxies.next()
                    mgr = BrowserManager(self.s)
                    try:
                        await mgr.start(proxy)
                    except Exception as exc:
                        log.error("w%d browser start failed: %s", wid, exc)
                        await asyncio.to_thread(self.store.release, job_id, str(exc))
                        await teardown()
                        await asyncio.sleep(5)
                        continue
                    browser_jobs = 0
                    ctx_jobs = self.s.context_max_jobs  # force fresh context

                if ctx is None or ctx_jobs >= self.s.context_max_jobs:
                    for closer in (page, ctx):
                        try:
                            if closer:
                                await closer.close()
                        except Exception:
                            pass
                    ctx = await mgr.new_context()
                    page = await ctx.new_page()
                    await warmup(page, self.s)
                    ctx_jobs = 0

                # -------- scrape --------
                try:
                    res = await scrape_one(page, query, self.s)
                except Blocked as exc:
                    self.stats.blocked += 1
                    self.stats.by_kind[exc.kind] = self.stats.by_kind.get(exc.kind, 0) + 1
                    await asyncio.to_thread(self.store.release, job_id, f"blocked: {exc}")

                    if exc.is_ban:
                        # IP is burned: bench the proxy, pause everyone, new browser.
                        log.warning("w%d BAN (%s) -> new proxy + %.0fs cooldown",
                                    wid, exc, self.s.block_cooldown_s)
                        await self.proxies.ban(proxy, 600)
                        self._trigger_cooldown()
                        await teardown()
                        ctx_jobs = browser_jobs = 0
                    else:
                        # Consent wall / JS gate: same IP is fine, just re-cookie.
                        log.info("w%d soft block (%s) -> fresh context", wid, exc)
                        ctx_jobs = self.s.context_max_jobs
                        await asyncio.sleep(random.uniform(1, 3))
                    continue
                except (NoAnswer, PWTimeout, PWError) as exc:
                    dead = await asyncio.to_thread(
                        self.store.retry, job_id, str(exc), self.s.max_attempts)
                    if dead:
                        self.stats.failed += 1
                    log.info("w%d retry/fail %r: %s", wid, query[:60], str(exc)[:120])
                    ctx_jobs = self.s.context_max_jobs  # fresh context next round
                    await asyncio.sleep(random.uniform(1, 3))
                    continue
                except Exception as exc:  # noqa: BLE001 - never kill the worker
                    dead = await asyncio.to_thread(
                        self.store.retry, job_id, repr(exc), self.s.max_attempts)
                    if dead:
                        self.stats.failed += 1
                    log.exception("w%d unexpected error", wid)
                    await teardown()
                    ctx_jobs = browser_jobs = 0
                    continue

                await asyncio.to_thread(self.store.complete, job_id, res.query,
                                        res.answer, res.sources, res.took_ms)
                self.stats.done += 1
                ctx_jobs += 1
                browser_jobs += 1

                await asyncio.sleep(random.uniform(self.s.min_delay_s,
                                                   self.s.max_delay_s))
        finally:
            await teardown()

    # ------------------------------------------------------------------ #
    async def _reporter(self) -> None:
        while not self._stop.is_set():
            await asyncio.sleep(20)
            st = await asyncio.to_thread(self.store.stats)
            log.info("[progress] %s", self.stats.line(st.get("pending", 0)))

    async def run(self) -> None:
        tasks = [asyncio.create_task(self._worker(i)) for i in range(self.s.workers)]
        rep = asyncio.create_task(self._reporter())
        try:
            await asyncio.gather(*tasks)
        finally:
            rep.cancel()
            st = await asyncio.to_thread(self.store.stats)
            log.info("[final] %s", self.stats.line(st.get("pending", 0)))
